import React from 'react'
import BigPic2 from "../../assets/images/leftPic.png"

export const LeftSection = () => {
  return (
    <div className="bg-[#175CD3] h-screen ">
    <div className='flex items-center justify-center mt-[60px]'><img src={BigPic2} alt="image" /></div>
    </div>
  )
}


