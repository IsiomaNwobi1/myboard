import React from 'react'
import BigPic4 from "../../assets/images/leftPic.png"

export const Left = () => {
  return (
    <div className="bg-[#175CD3] h-screen ">
    <div className='flex items-center justify-center mt-[60px]'><img src={BigPic4} alt="image" /></div>
    </div>
  )
}


