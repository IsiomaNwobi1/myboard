import React from 'react'
import BigPic from "../../assets/images/leftPic.png"

export const Left = () => {
  return (
    <div className="bg-[#175CD3] ">
    <div className='flex items-center justify-center mt-[60px]'><img src={BigPic} alt="image" /></div>
    </div>
  )
}
